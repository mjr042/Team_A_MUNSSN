const express = require('express');
const app = express();
var router = express.Router();
var fs = require('fs'); 
const bodyParser= require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded());

const fileUpload = require('express-fileupload');


var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/commenting');
var db = mongoose.connection;

app.use(fileUpload());


var User = require('./models/commentSchema');  

//just generate these 2 for testing once, then greytext them again!
//var testComment = new Comment({
//	username: 'fb3303' //no comment included, just init a username 
//});

//var testReply = new Comment({
//	username: 'jss912' //no comment included, just init a username 
//});


//save them once
//testComment.save(function(err){
//	if(err) throw err;
//	console.log('test comment saved db');
//});

//testReply.save(function(err){
//	if(err) throw err;
//	console.log('test comment saved db');
//});

var tempString

app.post('/comment', function(req, res) {   //when user updates their about me
	var tempString = req.body.fi;

//check if comment is empty, if it is, do below, if it is occupied, append comment to editHistory array, and set comment = editHistory[len(editHistory)]
//in that case where it was already occupied, show the message "test comment succesfully edited" in that case.
	User.findOneAndUpdate({ username: 'fb3303' }, { comment: tempString }, function(err, comment) {
	  if (err) throw err;

	  // updated users avatar base64 returned to us, use line under this to check if this here works
	  //console.log(user.avatar);
	  console.log('test commment succesfully placed')
	  console.log('current comment: ' + tempString)
	});
	res.redirect('/')  
})

app.post('/reply', function(req, res) {   //when user updates their about me
	var tempString = req.body.fa;

	User.findOneAndUpdate({ username: 'jss912' }, { parent: 'fb3303', comment: tempString }, function(err, comment) {
	  if (err) throw err;

	  // updated users avatar base64 returned to us, use line under this to check if this here works
	  //console.log(user.avatar);
	  console.log('test reply succesfully placed')
	  console.log('reply: ' + tempString)
	});
	res.redirect('/')  
})

//find and print all comments (2 in this test)
Comment.find({}, function(err, comments) { 
 if (err) throw err;

 //object of all the comments
  console.log(comments);
});

app.get('/', (req, res) => { 
    res.render('index.ejs')
})

app.listen(3019, function() { 
  console.log('listening on 3019') 
})
