const express = require('express');
const app = express();
var router = express.Router();
var fs = require('fs'); 
const bodyParser= require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }));

const path    = require("path");	
app.use(express.static(path.join(__dirname, 'public'))); //static dir

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/swagbitch');
var db = mongoose.connection;

var Comment = require('./models/commentSchema');  

//just generate these 2 for testing once, then greytext them again!
//var testComment = new Comment({
//	username: 'fb3303', //no comment included, just init a username 
//	comment: 'this is a test comment'
//});

//var testReply = new Comment({
//	username: 'jss912' //no comment included, just init a username 
//});


//save them once
//testComment.save(function(err){
//	if(err) throw err;
//	console.log('test comment saved db');
//});

//testReply.save(function(err){
//	if(err) throw err;
//	console.log('test comment saved db');
//});

var tempString

app.post('/comment', function(req, res) {   //when user updates their about me
	var tempString = req.body.fi; //get the text entered on front end 

//check if comment is empty
	Comment.findOne({ username: 'fb3303' }, function(err, comment) {
	  	if (comment == null) {
	  		var newCom = Comment({
	  		username: 'fb3303',
	  		comHistory : [tempString]
	  		});
	  		newCom.save(function(err) {
  				if (err) throw err;
  			console.log('comment created');
			});
	  	}

	//use this to clear edit history array
	//while(comment.comHistory.length > 0) {
	//  comHistory : comment.comHistory.pop()
	//}
	else {
	comHistory : comment.comHistory.push(tempString)
	commentIterator : comment.commentIterator = 1
	comment.save(function(err) {
        if (err) throw err;
    	console.log('comment succesfullly edited!');
  			})
		}
	})
	res.redirect('/')  
})


app.post('/reply', function(req, res) {   //when user updates their about me
	var tempString = req.body.fa;

	Comment.findOne({ username: 'jss912' }, function(err, comment) {
	  	if (comment == null) {
	  		var newCom = Comment({
	  		username: 'jss912',
	  		parent: 'fb3303',
	  		comHistory: [tempString]
	  		});
	  		newCom.save(function(err) {
  				if (err) throw err;
  			console.log('comment created');
			});
	  	}

	//use this to clear edit history array
	//while(comment.comHistory.length > 0) {
	//  comHistory : comment.comHistory.pop()
	//}
	else {
	comHistory : comment.comHistory.push(tempString)
	commentIterator : comment.commentIterator = 1
	comment.save(function(err) {
        if (err) throw err;
    	console.log('reply succesfullly edited!');
  			})
		}
	})
	res.redirect('/')  
})

//app.post('/back', function(req, res) {
//		var test = req.body
//		console.log(test)
//		res.redirect('/')  
//})

//app.post('/forward', function(req, res) {
//		res.redirect('/')  
//})

app.post('/back', function(req, res) { //used to view a previous version of a comment
		var commentId = req.body.backButton
		
		Comment.findOne({ username: commentId }, function(err, comment) {
			if (err) throw err;
			else if((comment.commentIterator + 1) > comment.comHistory.length) {
				console.log('sorry, thats out of bounds')
			}
			else {
			commentIterator : comment.commentIterator = comment.commentIterator + 1
			comment.save(function(err) {
        		if (err) throw err;
    			console.log('back success!');
				console.log(comment.commentIterator)
  				})
			}
		})
 		res.redirect('/')
  	})


app.post('/forward', function(req, res) { //used to view a newer version of a comment
		var commentId = req.body.forwardButton
		
		Comment.findOne({ username: commentId }, function(err, comment) {
			if (err) throw err;
			else if((comment.commentIterator - 1) < 1) {
				console.log('sorry, thats out of bounds')
			}
			else {
			commentIterator : comment.commentIterator = comment.commentIterator - 1
			comment.save(function(err) {
        		if (err) throw err;
    			console.log('forward success!');
				console.log(comment.commentIterator)
  				})
			}
		})
 		res.redirect('/')
  	})






//find and print all comments (2 in this test)
Comment.find({}, function(err, comments) { 
 if (err) throw err;

 //object of all the comments
  console.log(comments);
});

app.get('/', (req, res) => {
Comment.find({}, function(err, comm) {  //find current user and send data to display on accordion html(ejs) page
  		if (err) throw err;

  		res.render('index.ejs', {results : comm})
			});
});

app.listen(4000, function() { 
  console.log('listening on 4000') 
})
