const express = require('express');
const app = express();
var router = express.Router();
var fs = require('fs'); 
const bodyParser= require('body-parser')
var string = require('string')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded());

const fileUpload = require('express-fileupload');

const path    = require("path");	
app.use(express.static(path.join(__dirname, 'public'))); //static dir

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/upimg');
var db = mongoose.connection;

app.use(fileUpload());


var User = require('./models/userSchema');  

just generate these 2 for testing once, then greytext them again
var testUser = new User({
	username: 'fb3303'
});

var testUser2 = new User({
	username: 'jss135'
});

save them once
testUser.save(function(err){
	if(err) throw err;
	console.log('test user saved db');
});
testUser2.save(function(err){
	if(err) throw err;
	console.log('test user 2 saved to db')
})

var imge; 
var base64Image; 

//User.findOneAndUpdate({ username: 'fb3303' }, { avatar: '4AAQSkZJRgABAQAASABIAAD' }, function(err, user) {
//	  if (err) throw err;
//	});


app.post('/upload', function(req, res) {   //when user uploads a photo
	if(req.files.foo == undefined) { console.log('FUckingfag') }

	//else if(req.files.foo.size > 100) {
	//	console.log('please upload an file under 15mb')
	//}

	else {
	imge = req.files.foo.data;
	
	console.log('size in bytes: ' + Buffer(imge).size)

	base64Image = Buffer(imge).toString('base64');

	User.findOneAndUpdate({ username: 'fb3303' }, { avatar: base64Image }, function(err, user) {
	  if (err) throw err;

	  // updated users avatar base64 returned to us, use line under this to check if this here works
	  //console.log(user.avatar);
	  console.log('test users avatar succesfully updated')
		});
	}
	res.redirect('/')  
})

var tempString

app.post('/about', function(req, res) {   //when user updates their about me
	var tempString = req.body.fi;

	User.findOneAndUpdate({ username: 'fb3303' }, { aboutme: tempString }, function(err, user) {
	  if (err) throw err;

	  // updated users avatar base64 returned to us, use line under this to check if this here works
	  //console.log(user.avatar);
	  console.log('test users aboutme succesfully updated')
	  console.log('new about me: ' + tempString)
	});
	res.redirect('/')  
})

app.post('/resume', function(req, res) {   //when user updates their resume
	tempString = req.body.fa;

	User.findOneAndUpdate({ username: 'fb3303' }, { resume: tempString }, function(err, user) {
	  if (err) throw err;

	  // updated users avatar base64 returned to us, use line under this to check if this here works
	  //console.log(user.avatar);
	  console.log('test users aboutme succesfully updated')
	  console.log('new resume: ' + tempString)
	});
	res.redirect('/')  
})

app.post('/sched', function(req, res) {   //when user updates their schedule (interim format, may be changed later)
	tempString = req.body.fum;

	User.findOneAndUpdate({ username: 'fb3303' }, { schedule: tempString }, function(err, user) {
	  if (err) throw err;

	  // updated users avatar base64 returned to us, use line under this to check if this here works
	  //console.log(user.avatar);
	  console.log('test users schedule succesfully updated')
	  console.log('new resume: ' + tempString)



	});
	res.redirect('/')       
})  




app.get('/', (req, res) => {
User.findOne({ username: 'fb3303' }, function(err, user) {  //find current user and send data to display on accordion html(ejs) page
  		if (err) throw err;
  		console.log('faduhifudsahuifFU!!!')

  		ava = String(user.avatar)
  		ava = "data:image/jpg;base64,"+ava.substr(1,ava.length-2);
   		console.log(ava)

  		res.render('index.ejs', {avatar: ava, aboutme: user.aboutme, resume: user.resume, schedule: user.schedule})

			});
});


//find and print all users (2 in this test)
User.find({}, function(err, users) { 
 if (err) throw err;
 console.log('OFH						hudfduh							fjifdhf					OMG')
 //object of all the users
  console.log(users);
});

app.get('/', (req, res) => { 
    res.render('index.ejs')
})

app.listen(3027, function() { 
  console.log('listening on 3027') 
})
