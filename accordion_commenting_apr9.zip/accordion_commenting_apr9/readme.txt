These modules are only partially integrated into the final project, so I left them seperate as well if you want to test out there functionality better.

Instructions:
Start mongo db in a terminal window, open new terminal window, navigate to accordion or commenting directory, type: "node app.js" and go to localhost:4000 for commenting, or localhost:3027 for accordion.